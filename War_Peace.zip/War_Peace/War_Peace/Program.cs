﻿
        var filePath = "C:\\Users\\bmawela\\Documents\\War.txt";
        var text = File.ReadAllText(filePath);
        string[] warWords = text.Split(new char[] { ' ', '\n', '\r', '\t', '.', ',', ';', '!', '?' }, StringSplitOptions.RemoveEmptyEntries);

        Dictionary<string, int> countOfWords = new Dictionary<string, int>();

        foreach (string word in warWords)
        {
            var cleanedWord = word.ToLower();
            if (countOfWords.ContainsKey(cleanedWord))
                countOfWords[cleanedWord]++;
            else
                countOfWords.Add(cleanedWord, 1);
        }

        var resultsWordCount = countOfWords.OrderByDescending(kv => kv.Value).Take(50);

        var filteredWordCount = resultsWordCount.Where(kv => kv.Key.Length > 6).Take(50);
        foreach (var item in filteredWordCount)
            Console.WriteLine($"{item.Key}: {item.Value}");